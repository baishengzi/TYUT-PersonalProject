package arithmetic;

import arithmetic.MyExGUI;

public class ArithmeticTest8 {
    public static void main(String[] args) {
        MyExGUI exercise = new MyExGUI();
    }
}
